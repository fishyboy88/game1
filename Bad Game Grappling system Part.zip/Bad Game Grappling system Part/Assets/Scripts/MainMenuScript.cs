﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

//This Script useful in UI Related Programing Stuff in this Project
public class MainMenuScript : MonoBehaviour
{
    //A Global Reference varieble of camera which is use to show Bloom Effect in Scene 
    public Camera camera;

    //A Global Reference Text Variable which is use to show Total Money(in Dollar)
    public Text totalMoneyText;

    //A Global Integer Variable which calculate Total Money
    public int totalMoneyCounter;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //this function useful in call next scene as per buildIndex
    public void NextSceneCall(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
    }

    //Quit Game
    public void ExitCall()
    {
        Application.Quit();
    }
}
